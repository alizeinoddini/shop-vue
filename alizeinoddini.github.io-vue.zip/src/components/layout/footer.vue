<template>
  <footer class="footer">
    <div>
      <p class="text-center">کپی رایت © 2023 تمامی حقوق محفوظ است.</p>
    </div>
  </footer>
</template>

<script>
export default {
  name: "FooterVue",
};
</script>
