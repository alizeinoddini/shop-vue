<template>
  <div
    class="intro-slide"
    style="background-image: url(images/baner/slide-1.png)"
  >
    <div class="container intro-content text-left">
      <h1 class="intro-title">تبلت<br /><strong>مایکروسافت</strong></h1>

      <a href="#" class="btn btn-warning btn-sm">خرید</a>
    </div>
  </div>
  <br />
</template>

<script>
export default {
  name: "HomeSection",
};
</script>
